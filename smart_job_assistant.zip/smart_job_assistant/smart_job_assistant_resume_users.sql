-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (arm64)
--
-- Host: 127.0.0.1    Database: smart_job_assistant
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `resume_users`
--

DROP TABLE IF EXISTS `resume_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resume_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `full_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `github` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu1_degree` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu1_school` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu1_start` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu1_end` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu1_major` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu1_gpa` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu2_degree` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu2_school` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu2_start` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu2_end` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu2_major` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu2_gpa` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu3_degree` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu3_school` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu3_start` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu3_end` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu3_major` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edu3_gpa` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int1_company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int1_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int1_period` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int1_responsibility` longtext COLLATE utf8mb4_unicode_ci,
  `int2_company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int2_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int2_period` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int2_responsibility` longtext COLLATE utf8mb4_unicode_ci,
  `int3_company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int3_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int3_period` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `int3_responsibility` longtext COLLATE utf8mb4_unicode_ci,
  `work1_company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work1_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work1_period` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work1_responsibility` longtext COLLATE utf8mb4_unicode_ci,
  `work1_reason_leave` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work2_company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work2_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work2_period` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work2_responsibility` longtext COLLATE utf8mb4_unicode_ci,
  `work2_reason_leave` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work3_company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work3_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work3_period` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work3_responsibility` longtext COLLATE utf8mb4_unicode_ci,
  `work3_reason_leave` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proj1_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proj1_period` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proj1_details` longtext COLLATE utf8mb4_unicode_ci,
  `proj2_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proj2_period` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proj2_details` longtext COLLATE utf8mb4_unicode_ci,
  `proj3_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proj3_period` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proj3_details` longtext COLLATE utf8mb4_unicode_ci,
  `programming_skills` longtext COLLATE utf8mb4_unicode_ci,
  `office_skills` longtext COLLATE utf8mb4_unicode_ci,
  `languages` longtext COLLATE utf8mb4_unicode_ci,
  `comp1_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comp1_award` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comp1_year` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comp2_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comp2_award` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comp2_year` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comp3_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comp3_award` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comp3_year` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `others` longtext COLLATE utf8mb4_unicode_ci,
  `resume_raw` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resume_users`
--

LOCK TABLES `resume_users` WRITE;
/*!40000 ALTER TABLE `resume_users` DISABLE KEYS */;
INSERT INTO `resume_users` VALUES (1,'Unknown',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Job Title: Software Engineer (Full Stack)\nCompany Overview\nAn innovative software company focusing on AI-powered productivity tools. We are seeking talented full-stack engineers to join our dynamic and fast-growing team.\nResponsibilities\n• Design, develop, and maintain scalable web applications using React and FastAPI.\n• Collaborate with data scientists and product managers to integrate AI models into production systems.\n• Optimize database queries and API performance for high-traffic workloads.\n• Write clean, maintainable, and well-documented code.\nRequirements\n• Bachelor\'s or Master\'s degree in Computer Science, Software Engineering, or a related field.\n• Proficiency in Python, JavaScript, and SQL.\n• Experience with Flask/FastAPI and modern frontend frameworks (React/Vue).\n• Familiarity with cloud services (AWS, GCP, or Azure) and containerization (Docker).\n• Strong problem-solving, communication, and teamwork skills.\n• Bonus: Experience working with LLM APIs (OpenAI, Qwen, Anthropic, etc.).\nLocation\nRemote or On-site\nCompensation\nCompetitive salary, flexible work hours, and career growth opportunities.','2025-11-14 09:00:47','2025-11-14 09:00:47'),(2,'Unknown',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Job Title: Software Engineer (Full Stack)\nCompany Overview\nAn innovative software company focusing on AI-powered productivity tools. We are seeking talented full-stack engineers to join our dynamic and fast-growing team.\nResponsibilities\n• Design, develop, and maintain scalable web applications using React and FastAPI.\n• Collaborate with data scientists and product managers to integrate AI models into production systems.\n• Optimize database queries and API performance for high-traffic workloads.\n• Write clean, maintainable, and well-documented code.\nRequirements\n• Bachelor\'s or Master\'s degree in Computer Science, Software Engineering, or a related field.\n• Proficiency in Python, JavaScript, and SQL.\n• Experience with Flask/FastAPI and modern frontend frameworks (React/Vue).\n• Familiarity with cloud services (AWS, GCP, or Azure) and containerization (Docker).\n• Strong problem-solving, communication, and teamwork skills.\n• Bonus: Experience working with LLM APIs (OpenAI, Qwen, Anthropic, etc.).\nLocation\nRemote or On-site\nCompensation\nCompetitive salary, flexible work hours, and career growth opportunities.','2025-11-14 09:02:10','2025-11-14 09:02:10'),(3,'Unknown',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Job Title: Software Engineer (Full Stack)\nCompany Overview\nAn innovative software company focusing on AI-powered productivity tools. We are seeking talented full-stack engineers to join our dynamic and fast-growing team.\nResponsibilities\n• Design, develop, and maintain scalable web applications using React and FastAPI.\n• Collaborate with data scientists and product managers to integrate AI models into production systems.\n• Optimize database queries and API performance for high-traffic workloads.\n• Write clean, maintainable, and well-documented code.\nRequirements\n• Bachelor\'s or Master\'s degree in Computer Science, Software Engineering, or a related field.\n• Proficiency in Python, JavaScript, and SQL.\n• Experience with Flask/FastAPI and modern frontend frameworks (React/Vue).\n• Familiarity with cloud services (AWS, GCP, or Azure) and containerization (Docker).\n• Strong problem-solving, communication, and teamwork skills.\n• Bonus: Experience working with LLM APIs (OpenAI, Qwen, Anthropic, etc.).\nLocation\nRemote or On-site\nCompensation\nCompetitive salary, flexible work hours, and career growth opportunities.','2025-11-14 09:12:39','2025-11-14 09:12:39'),(4,'Unknown',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Job Title: Software Engineer (Full Stack)\nCompany Overview\nAn innovative software company focusing on AI-powered productivity tools. We are seeking talented full-stack engineers to join our dynamic and fast-growing team.\nResponsibilities\n• Design, develop, and maintain scalable web applications using React and FastAPI.\n• Collaborate with data scientists and product managers to integrate AI models into production systems.\n• Optimize database queries and API performance for high-traffic workloads.\n• Write clean, maintainable, and well-documented code.\nRequirements\n• Bachelor\'s or Master\'s degree in Computer Science, Software Engineering, or a related field.\n• Proficiency in Python, JavaScript, and SQL.\n• Experience with Flask/FastAPI and modern frontend frameworks (React/Vue).\n• Familiarity with cloud services (AWS, GCP, or Azure) and containerization (Docker).\n• Strong problem-solving, communication, and teamwork skills.\n• Bonus: Experience working with LLM APIs (OpenAI, Qwen, Anthropic, etc.).\nLocation\nRemote or On-site\nCompensation\nCompetitive salary, flexible work hours, and career growth opportunities.','2025-11-14 09:17:31','2025-11-14 09:17:31'),(5,'Unknown',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Job Title: Software Engineer (Full Stack)\nCompany Overview\nAn innovative software company focusing on AI-powered productivity tools. We are seeking talented full-stack engineers to join our dynamic and fast-growing team.\nResponsibilities\n• Design, develop, and maintain scalable web applications using React and FastAPI.\n• Collaborate with data scientists and product managers to integrate AI models into production systems.\n• Optimize database queries and API performance for high-traffic workloads.\n• Write clean, maintainable, and well-documented code.\nRequirements\n• Bachelor\'s or Master\'s degree in Computer Science, Software Engineering, or a related field.\n• Proficiency in Python, JavaScript, and SQL.\n• Experience with Flask/FastAPI and modern frontend frameworks (React/Vue).\n• Familiarity with cloud services (AWS, GCP, or Azure) and containerization (Docker).\n• Strong problem-solving, communication, and teamwork skills.\n• Bonus: Experience working with LLM APIs (OpenAI, Qwen, Anthropic, etc.).\nLocation\nRemote or On-site\nCompensation\nCompetitive salary, flexible work hours, and career growth opportunities.','2025-11-14 09:18:36','2025-11-14 09:18:36'),(6,'Unknown',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Job Title: Software Engineer (Full Stack)\nCompany Overview\nAn innovative software company focusing on AI-powered productivity tools. We are seeking talented full-stack engineers to join our dynamic and fast-growing team.\nResponsibilities\n• Design, develop, and maintain scalable web applications using React and FastAPI.\n• Collaborate with data scientists and product managers to integrate AI models into production systems.\n• Optimize database queries and API performance for high-traffic workloads.\n• Write clean, maintainable, and well-documented code.\nRequirements\n• Bachelor\'s or Master\'s degree in Computer Science, Software Engineering, or a related field.\n• Proficiency in Python, JavaScript, and SQL.\n• Experience with Flask/FastAPI and modern frontend frameworks (React/Vue).\n• Familiarity with cloud services (AWS, GCP, or Azure) and containerization (Docker).\n• Strong problem-solving, communication, and teamwork skills.\n• Bonus: Experience working with LLM APIs (OpenAI, Qwen, Anthropic, etc.).\nLocation\nRemote or On-site\nCompensation\nCompetitive salary, flexible work hours, and career growth opportunities.','2025-11-14 09:21:37','2025-11-14 09:21:37'),(7,'Unknown',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Job Title: Software Engineer (Full Stack)\nCompany Overview\nAn innovative software company focusing on AI-powered productivity tools. We are seeking talented full-stack engineers to join our dynamic and fast-growing team.\nResponsibilities\n• Design, develop, and maintain scalable web applications using React and FastAPI.\n• Collaborate with data scientists and product managers to integrate AI models into production systems.\n• Optimize database queries and API performance for high-traffic workloads.\n• Write clean, maintainable, and well-documented code.\nRequirements\n• Bachelor\'s or Master\'s degree in Computer Science, Software Engineering, or a related field.\n• Proficiency in Python, JavaScript, and SQL.\n• Experience with Flask/FastAPI and modern frontend frameworks (React/Vue).\n• Familiarity with cloud services (AWS, GCP, or Azure) and containerization (Docker).\n• Strong problem-solving, communication, and teamwork skills.\n• Bonus: Experience working with LLM APIs (OpenAI, Qwen, Anthropic, etc.).\nLocation\nRemote or On-site\nCompensation\nCompetitive salary, flexible work hours, and career growth opportunities.','2025-11-14 09:23:30','2025-11-14 09:23:30'),(8,'Unknown',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Job Title: Software Engineer (Full Stack)\nCompany Overview\nAn innovative software company focusing on AI-powered productivity tools. We are seeking talented full-stack engineers to join our dynamic and fast-growing team.\nResponsibilities\n• Design, develop, and maintain scalable web applications using React and FastAPI.\n• Collaborate with data scientists and product managers to integrate AI models into production systems.\n• Optimize database queries and API performance for high-traffic workloads.\n• Write clean, maintainable, and well-documented code.\nRequirements\n• Bachelor\'s or Master\'s degree in Computer Science, Software Engineering, or a related field.\n• Proficiency in Python, JavaScript, and SQL.\n• Experience with Flask/FastAPI and modern frontend frameworks (React/Vue).\n• Familiarity with cloud services (AWS, GCP, or Azure) and containerization (Docker).\n• Strong problem-solving, communication, and teamwork skills.\n• Bonus: Experience working with LLM APIs (OpenAI, Qwen, Anthropic, etc.).\nLocation\nRemote or On-site\nCompensation\nCompetitive salary, flexible work hours, and career growth opportunities.','2025-11-14 09:24:19','2025-11-14 09:24:19'),(9,'Unknown',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Job Title: Software Engineer (Full Stack)\nCompany Overview\nAn innovative software company focusing on AI-powered productivity tools. We are seeking talented full-stack engineers to join our dynamic and fast-growing team.\nResponsibilities\n• Design, develop, and maintain scalable web applications using React and FastAPI.\n• Collaborate with data scientists and product managers to integrate AI models into production systems.\n• Optimize database queries and API performance for high-traffic workloads.\n• Write clean, maintainable, and well-documented code.\nRequirements\n• Bachelor\'s or Master\'s degree in Computer Science, Software Engineering, or a related field.\n• Proficiency in Python, JavaScript, and SQL.\n• Experience with Flask/FastAPI and modern frontend frameworks (React/Vue).\n• Familiarity with cloud services (AWS, GCP, or Azure) and containerization (Docker).\n• Strong problem-solving, communication, and teamwork skills.\n• Bonus: Experience working with LLM APIs (OpenAI, Qwen, Anthropic, etc.).\nLocation\nRemote or On-site\nCompensation\nCompetitive salary, flexible work hours, and career growth opportunities.','2025-11-14 12:23:39','2025-11-14 12:23:39');
/*!40000 ALTER TABLE `resume_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-14 20:43:01
